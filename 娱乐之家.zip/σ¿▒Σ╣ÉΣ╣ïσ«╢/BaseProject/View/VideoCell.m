//
//  VideoCell.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCell.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
@implementation VideoCell
//为了保证同一时间只有一个播放器，使用单例模式
+ (AVPlayerViewController *)sharedInstance
{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
    });
    return vc;
}
//懒加载
- (UILabel *)titleLb
{
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = [UIFont systemFontOfSize:18];
    }
    return _titleLb;
}

- (UILabel *)descLb
{
    if (_descLb == nil) {
        _descLb = [[UILabel alloc]init];
        _descLb.font =[UIFont systemFontOfSize:14];
        _descLb.textColor = [UIColor lightGrayColor];
    }
    return _descLb;
}

- (UIButton *)iconBtn
{
    if (_iconBtn == nil) {
        _iconBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_iconBtn bk_addEventHandler:^(id sender) {
           //点击方法
            AVPlayer *player = [AVPlayer playerWithURL:self.videoURL];
            [player play];
            [VideoCell sharedInstance].player = player;
            [sender addSubview:[VideoCell sharedInstance].view];
            [[VideoCell sharedInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
            }];
            
        } forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _iconBtn;
}

//初始化方法
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.descLb];
        [self.contentView addSubview:self.iconBtn];
        //AutoLayout布局
        /** title*/
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(5);
            make.right.mas_equalTo(-5);
        }];
        /** desc*/
        [self.descLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(5);
            make.right.mas_equalTo(-5);
        }];
        /** iconBtn*/
        [self.iconBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.descLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(5);
            make.right.mas_equalTo(-5);
            make.height.mas_equalTo(180);
            make.bottom.mas_equalTo(-10);
        }];
    }
    return self;
}

//如果cell被复用，需要把cell上的播放器删掉
- (void)prepareForReuse
{
    [super prepareForReuse];
    //判断当前cell是否有播放，如果有则删除
    if ([VideoCell sharedInstance].view.superview == self.iconBtn) {
        [[VideoCell sharedInstance].view removeFromSuperview];
        [VideoCell sharedInstance].player = nil;
    }
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
