//
//  XSViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "XSViewController.h"
#import "GuoViewModel.h"
#import "GuoViewCell.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "Factory.h"

@interface XSViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) GuoViewModel *guoVM;
@end

@implementation XSViewController
+ (UINavigationController *)XSNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        XSViewController *vc = [XSViewController new];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}


- (GuoViewModel *)guoVM
{
    if (!_guoVM) {
        _guoVM = [GuoViewModel new];
    }
    return _guoVM;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        
        
        [_tableView registerClass:[GuoViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
           }
    return _tableView;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.guoVM.rowNumber;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GuoViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    //****
    cell.iconIV  = (TRImageView *)[cell.contentView viewWithTag:100];
    cell.titleLb = (UILabel *)[cell.contentView viewWithTag:200];
    [cell.iconIV.imageView setImageWithURL:[self.guoVM imageURLForRow:indexPath.row]];
    cell.titleLb.text = [self.guoVM titleForRow:indexPath.row];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
//-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return UITableViewAutomaticDimension;
//}
kRemoveCellSeparator
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //添加后台播放
    //[[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    //[[AVAudioSession sharedInstance] setActive:YES error:nil];
    
    
    
    //AVPlayerViewController *vc = [AVPlayerViewController new];
    //AVPlayer *player = [AVPlayer playerWithURL:[self.guoVM audioURLForRow:indexPath.row]];
    //vc.player = player;
    //[self presentViewController:vc animated:YES completion:nil];
    //[vc.player play];
    
    //添加后台播放模式,需要在plist文件中添加background modes
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    
    AVPlayerViewController *vc=[AVPlayerViewController new];
    AVPlayer *player=[AVPlayer playerWithURL:[self.guoVM audioURLForRow:indexPath.row]];
    vc.player = player;
    [self presentViewController:vc animated:YES completion:nil];
    [vc.player play];  //弹出之后 自动播放
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"相声";
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.guoVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
        }];
    }];
    [self.tableView.header beginRefreshing];
    self.tableView.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        [self.guoVM getMoreDataCompletionHanld:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    [Factory addMenuItemToVC:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
