//
//  BeautifulViewModel.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BeautifulViewModel.h"

@implementation BeautifulViewModel
 - (NSInteger)rowNumber{
    return self.dataArr.count;
}
- (void)refreshDataCompleteHandle:(void (^)(NSError *))complete{
    _page = 1;
    [self getDataCompleteHandle:complete];
}
- (void)getMoreDataCompleteHandle:(void (^)(NSError *))complete{
    _page += 1;
    [self getDataCompleteHandle:complete];
}
- (void)getDataCompleteHandle:(void (^)(NSError *))complete{
    [AlbumNetManager getBeautifulWomanForPage:_page completionHandle:^(AlbumModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data];
        complete(error);
    }];
}
- (NSURL *)iconForRow:(NSInteger)row{
    AlbumDataModel *data = self.dataArr[row];
    return [NSURL URLWithString:data.coverUrl];
}


@end











