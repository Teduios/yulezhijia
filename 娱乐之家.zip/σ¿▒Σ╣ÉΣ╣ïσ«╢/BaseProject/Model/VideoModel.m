//
//  VideoModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoModel.h"

@implementation VideoModel
+ (NSDictionary *)objectClassInArray
{
    return @{@"videoSidList":[VideoVideoListModel class],@"videoList":[VideoVideoListModel class]};
}
@end

@implementation VideoVideoListModel
//系统关键词的替换
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"desc": @"description",
             @"m3u8Url": @"m3u8_url",
             @"m3u8HdUrl":@"m3u8Hd_url",
             @"mp4Url":@"mp4_url",
             @"mp4HdUrl":@"mp4Hd_url"
             };
//命名：单词小写，以_间隔
//+ (NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName{
//   return [propertyName underlineFromCamel];
//}

}
@end

@implementation VideoVideoSidListModel

@end
