//
//  XiangShengModel.h
//  BaseProject
//
//  Created by tarena on 15/10/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class XiangShengTracksModel,XiangShengAlbumModel;
@interface XiangShengModel : BaseModel
//album不新建 是因为用不上
@property (nonatomic,strong)XiangShengAlbumModel *album;
@property (nonatomic,strong)NSNumber *msg;
@property (nonatomic,strong)NSNumber *ret;
@property (nonatomic,strong)XiangShengTracksModel *tracks;
@end
//tracks
@interface XiangShengTracksModel : BaseModel
@property (nonatomic,strong)NSArray *list;
@property (nonatomic,strong)NSNumber *maxPageId;
@property (nonatomic,strong)NSNumber *pageId;
@property (nonatomic,strong)NSNumber *pageSize;
@property (nonatomic,strong)NSNumber *totalCount;
@end

@interface XiangShengTracksListModel : BaseModel
@property (nonatomic,strong)NSNumber *albumld;
@property (nonatomic,strong)NSString *albumImage;
@property (nonatomic,strong)NSString *albumTitle;
@property (nonatomic,strong)NSNumber *comments;
@property (nonatomic,strong)NSString *coverLarge;
@property (nonatomic,strong)NSString *coverMiddle;
@property (nonatomic,strong)NSString *coverSmall;
@property (nonatomic,strong)NSNumber *createdAt;
@property (nonatomic,strong)NSNumber *downloadAacSize;
@property (nonatomic,strong)NSString *downloadAacUrl;
@property (nonatomic,strong)NSNumber *downloadSize;
@property (nonatomic,strong)NSString *downloadUrl;
@property (nonatomic,strong)NSNumber *duration;
@property (nonatomic,strong)NSNumber *isPublic;
@property (nonatomic,strong)NSNumber *likes;
@property (nonatomic,strong)NSString *nickname;
@property (nonatomic,strong)NSNumber *opType;
@property (nonatomic,strong)NSNumber *orderNum;
@property (nonatomic,strong)NSString *playPathAacv164;
@property (nonatomic,strong)NSString *playPathAacv224;
@property (nonatomic,strong)NSNumber *playtimes;
@property (nonatomic,strong)NSString *playUrl32;
@property (nonatomic,strong)NSString *playUrl64;
@property (nonatomic,strong)NSNumber *processState;
@property (nonatomic,strong)NSNumber *shares;
@property (nonatomic,strong)NSString *smallLogo;
@property (nonatomic,strong)NSNumber *status;
@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSNumber *trackId;
@property (nonatomic,strong)NSNumber *uid;
@property (nonatomic,strong)NSNumber *userSource;

@end
//album
@interface XiangShengAlbumModel:BaseModel
@property (nonatomic, assign) double status;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *tags;
@property (nonatomic, assign) double serialState;
@property (nonatomic, strong) NSString *categoryName;
@property (nonatomic, strong) NSString *coverWebLarge;
@property (nonatomic, strong) NSString *coverMiddle;
@property (nonatomic, assign) BOOL hasNew;
@property (nonatomic, strong) NSString *nickname;
@property (nonatomic, strong) NSString *intro;
@property (nonatomic, assign) double shares;
@property (nonatomic, assign) BOOL isVerified;
@property (nonatomic, assign) double createdAt;
@property (nonatomic, strong) NSString *avatarPath;
@property (nonatomic, assign) double albumId;
@property (nonatomic, assign) double updatedAt;
@property (nonatomic, strong) NSString *coverLarge;
@property (nonatomic, strong) NSString *coverSmall;
@property (nonatomic, assign) double uid;
@property (nonatomic, strong) NSString *coverOrigin;
@property (nonatomic, strong) NSString *introRich;
@property (nonatomic, assign) double tracks;
@property (nonatomic, assign) BOOL isFavorite;
@property (nonatomic, assign) double serializeStatus;
@property (nonatomic, assign) double categoryId;
@property (nonatomic, assign) double playTimes;
@end











