//
//  AlbumNetManager.h
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "AlbumModel.h"

@interface AlbumNetManager : BaseNetManager

+ (id)getBeautifulWomanForPage:(NSInteger)page completionHandle:(void(^)(AlbumModel *model, NSError *error))complete;


@end



















