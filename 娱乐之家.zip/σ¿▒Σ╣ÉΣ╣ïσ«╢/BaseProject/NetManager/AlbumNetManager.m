//
//  AlbumNetManager.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AlbumNetManager.h"

@implementation AlbumNetManager

+ (id)getBeautifulWomanForPage:(NSInteger)page completionHandle:(void(^)(AlbumModel *model, NSError *error))complete{
    NSString *path=@"http://box.dwstatic.com/apiAlbum.php";
    NSDictionary *params=@{@"action":@"l", @"albumsTag":@"beautifulWoman", @"p":@(page), @"v":@"77", @"OSType":@"iOS8.2", @"versionName":@"2.1.7"};
//    return [self Get:path parameters:params completionHandler:^(id responseObj, NSError *error) {
//        complete([AlbumModel objectWithKeyValues:responseObj], error);
//    }];
    return  [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        complete([AlbumModel objectWithKeyValues:responseObj], error);
    }];
}

@end













