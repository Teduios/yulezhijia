//
//  GuoViewModel.h
//  BaseProject
//
//  Created by tarena on 15/10/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "GuoNetManager.h"
@interface GuoViewModel : BaseViewModel
//多少行
@property (nonatomic)NSInteger rowNumber;
- (NSURL *)imageURLForRow: (NSInteger)row;
- (NSString *)titleForRow: (NSInteger)row;
//通过 获取地址
- (NSURL *)audioURLForRow: (NSInteger)row;
 
//刷新  加载更多
@property (nonatomic)NSInteger pageId;
- (void)refreshDataCompletionHandle:(void(^)(NSError *error))completionHandle;
- (void)getMoreDataCompletionHanld:(void(^)(NSError *error))completionHandle;
 
//最大页数
@property (nonatomic) NSInteger maxPageId;
@end
