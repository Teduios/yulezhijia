//
//  BeautifulViewModel.h
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "AlbumNetManager.h"

@interface BeautifulViewModel : BaseViewModel

@property(nonatomic) NSInteger rowNumber;

- (NSURL *)iconForRow:(NSInteger)row;
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete;
- (void)getMoreDataCompleteHandle:(void(^)(NSError *error))complete;

@property(nonatomic) NSInteger page;
@property(nonatomic,strong) NSMutableArray *dataArr;

@end














