//
//  XiangShengModel.m
//  BaseProject
//
//  Created by tarena on 15/10/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "XiangShengModel.h"

@implementation XiangShengModel

@end
@implementation XiangShengTracksModel

+ (NSDictionary *)objectClassInArray//数组中的类对象
{
    return @{@"list":[XiangShengTracksListModel class]};
}

@end
@implementation XiangShengTracksListModel



@end
@implementation XiangShengAlbumModel

 

@end