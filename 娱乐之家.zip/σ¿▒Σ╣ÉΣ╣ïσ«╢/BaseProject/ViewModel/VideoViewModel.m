//
//  VideoViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewModel.h"

@implementation VideoViewModel
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
//创建videoListModel   ??
- (VideoVideoListModel *)videoListModelForRow: (NSInteger)row
{
    return self.dataArr[row];
}
/** 获取视频的标题*/
- (NSString *)titleForRow: (NSInteger)row
{
    return [self videoListModelForRow:row].title;
}
/** 获取视频的描述*/
- (NSString *)descForRow: (NSInteger)row
{
    return [self videoListModelForRow:row].desc;
}
/** 获取图片*/
- (NSURL *)iconURLForRow: (NSInteger)row
{
    NSString *path = [self videoListModelForRow:row].cover;
    return [NSURL URLWithString:path];
}
/** 获取视频*/
- (NSURL *)videoURLForRow: (NSInteger)row
{
    NSString *path = [self videoListModelForRow:row].mp4Url;
    return [NSURL URLWithString:path];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [VideoNetManager getVideoWithIndex:_index completionHandle:^(VideoModel *model, NSError *error) {
        if (_index == 0) {
            [self.dataArr removeAllObjects];
        }
        //隐式转换：VideoModel *m = (VideoModel *)model;
        [self.dataArr addObjectsFromArray:model.videoList];
        completionHandle(error);
    }];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _index = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取更多数据
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _index += 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}






























@end
