//
//  VideoViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoNetManager.h"
@interface VideoViewModel : BaseViewModel
//数据的行数和索引
@property (nonatomic) NSInteger rowNumber;
@property (nonatomic) NSInteger index;

/** 获取视频的标题*/
- (NSString *)titleForRow: (NSInteger)row;
/** 获取视频的描述*/
- (NSString *)descForRow: (NSInteger)row;
/** 获取图片*/
- (NSURL *)iconURLForRow: (NSInteger)row;
/** 获取视频*/
- (NSURL *)videoURLForRow: (NSInteger)row;
@end
